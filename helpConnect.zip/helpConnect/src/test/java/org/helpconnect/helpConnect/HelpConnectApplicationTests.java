package org.helpconnect.helpConnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelpConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
